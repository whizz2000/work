<?php
//后台公共的函数
//顶级分类
	function getCateInfo($cateInfo,$prant_id=0,$lever=1){
		static $info=[];
		foreach($cateInfo as $k=>$v){
			if($v['parent_id']==$prant_id){
				$v['lever']=$lever; 
				$info[]=$v;
				getCateInfo($cateInfo,$v['cate_id'],$v['lever']+1);
			}
		}
		return $info; 
	}

	
	
?>
