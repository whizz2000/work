<?php
namespace app\admin\controller;

use think\Controller;

class Admin extends Common{
	//管理员添加视图
		public function create(){
		return $this->fetch('create');
	}

	//管理员添加执行
	public function save(){
		$data = input('post.');
		$admin_model=model('admin');//model实例化

		//验证
		if(empty($data['admin_name'])){
		$this->error("管理员名称必填");
	}else{
		$where=[
			['account','=',$data['admin_name']]	
		];
		$adminInfo=$admin_model->where($where)->find();
		if(!empty($adminInfo)){
			$this->error("管理员名称已经存在");
			}
	}

		//把文件上传 然后保存到data;
			$myfile=$_FILES['admin_logo'];
	if($myfile['error']!=0){
		$this->error("文件上传信息有误");
	}else{ 
		$file = request()->file('admin_logo');//
		$info =$file->move('./static/adminlogo');// ./从入口文件开始
//print_r($info);exit;
		
		if(empty($info)){
			$this->error('上传失败');exit;
		}
		$data['admin_logo']='/static/adminlogo/'. $info->getSaveName();//获取保存路径的名字
		
	}
		
		
		//$data['brand_logo']=文件上传成功后的路径
		//入库
		$res=$admin_model->save($data);
		if($res){
			$this->success('添加成功','admin/index');
		}else{
			$this->error('添加失败');
		}


	}




	//展示视图页面
		public function index(){
					$query=input('get.');//可以写成input();
					$where=[];
					if(!empty($query['admin_name'])){
						$where[]=['account','like',"%".$query['admin_name'].'%'];
					}
					
					//print_r($where);

					$admin_model=model('admin');//model实例化
					$adminInfo=$admin_model->where($where)->paginate(4,false,['query'=>$query]);

					$this->assign('adminInfo',$adminInfo);
					$this->assign('query',$query);

					return $this->fetch('index');
				}


		//删除

		public function delete(){
			$admin_id=input('get.admin_id');
			$admin_model=model('admin');
			$where=[
				['id','=',$admin_id]	
			];
			$res=$admin_model->where($where)->delete();
					if($res){
					$this->success('删除成功','admin/index');
				}else{
					$this->error('删除失败');
				}
		}











}










?>