<?php

namespace app\admin\controller;

use think\Controller;
use think\Request;

class Student extends Common
{
   function index(){
		return $this->fetch();
   }
	//添加页面视图
    function create(){
		//写活下拉菜单
		$class_model=model('Listen');
		$classInfo=$class_model->select();
		$this->assign('classInfo',$classInfo);

		return $this->fetch();
   }
   //添加页面执行
   public function save(){
		$data=input('post.');
		$student_model=model('Baby');
		
	
		$res=$student_model->save();
		if($res){
			$this->success('添加成功','Baby/index');
		}else {
			$this->error('添加失败');
		}
   }
}
