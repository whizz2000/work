<?php
namespace app\admin\controller;
use think\Controller;
class Brand extends Common{
	//品牌的视图页面
	public function create(){
		return $this->fetch();
	}
	//品牌的添加页面
	public function save(){
		$data=input('post.');
		$brand_model=model('Brand');
		//验证品牌名称
		if(empty($data['brand_name'])){
			$this->error('品牌名称不能为空');exit;
		}else{
			$brandInfo=$brand_model->where('brand_name','=',$data['brand_name'])->count();
			if($brandInfo>0){
				$this->error('品牌名称已经被添加');
			}
		}
		//验证路径不能为空
			if(empty($data['brand_url'])){
				$this->error('添加路径不能为空');exit;
			}
		//上传文件
		$myfile=$_FILES['w'];
			if($myfile['error']!=0){
				$this->error('文件上传有误');
			}else{
				$file=request()->file('brand_logo');
				$info=$file->move('./static/brandlogo');
				if(empty($info)){
					$this->error('文件上传有误');
				}
				$data['brand_logo']='/static/brandlogo/'.$info->getSaveName();

			}
			$res=$brand_model->save($data);
			
			if($res){
				$this->success('添加成功','brand/index');
			}else{
				$this->error('添加失败');
			}
	}
	//展示页面
	public function index(){
		$query=input('get.');
		$where=[];
		if(!empty($query['brand_name'])){
			$where[]=['brand_name','like',"%".$query['brand_name']."%"];
		}
		if(!empty($query['brand_url'])){
			$where[]=['brand_url','like',"%".$query['brand_url']."%"];
		}
		//print_r($where);
		$brand_model=model('Brand');
		$brandInfo=$brand_model->where($where)->paginate(5,false,['query'=>$query]);
		$this->assign('brandInfo',$brandInfo);
		return $this->fetch();
		
	}

	//删除
	public function delete(){
		$brand_id=input('get.brand_id');	
		$brand_model=model('Brand');
		$res=$brand_model->where('brand_id','=',$brand_id)->delete();
		
		if($res){
			$this->success('删除成功','brand/index');
		}else{
			$this->error('删除失败');
		}
	}
		
}
?>