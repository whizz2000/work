<?php

namespace app\admin\controller;

use think\Controller;

class Category extends Common
{

	//分类的展示
	public function index(){  
		$cateInfo=$this->getCateInfo();
		$this->assign('cateInfo',$cateInfo);
		return $this->fetch('index');

	
	}
     //分类的添加
	public function create(){
		//查询所有分类作为下拉菜单的值
		$cateInfo=$this->getCateInfo();
		//print_r($cateInfo);exit;
		$this->assign('cateInfo',$cateInfo);
	
		return $this->fetch('create');
	}
	

	public function save(){
		$data=input('post.');
		//print_r($data);
		//验证
			if(empty($data['cate_name'])){
				$this->error("分类名不能为空");die;
			}
			
		//非空唯一
				$where=[
					['cate_name','=',$data['cate_name']],
					['parent_id','=',$data['parent_id']]
				];
				$www=model('category')->where($where)->find();
				if($www){
					$this->error('该分类已经存在');die;
				}

		$cate_model=model('Category');
		$res=$cate_model->save($data);
			if($res){
				$this->success('添加成功',url('category/index'));
			}else{
				$this->error('添加失败');	
			}
	}

		//删除
			public function cateDel(){
				
				$cate_model=model('Category');
				$cate_id=input('get.cate_id');
				$where=[
					['parent_id','=',$cate_id]
				];
				$count=$cate_model->where($where)->count();
				if($count>0){
					$this->error("此分类下有子类不允许删除");exit;
				}else{
						$res=$cate_model->where('cate_id','=',$cate_id)->delete();
						if($res==true){//由于返回的布尔值是 true 或者false
							$this->success('删除成功');
						}else{
							$this->error('删除失败');
						}
				}
				
			}

			

	//修改的展示页面
		public function update(){
			$cate_model=model('Category');
			$cate_id=input('get.cate_id');

			$where=[
				['cate_id','=',$cate_id]	
			];
			$cateArr=$cate_model->where($where)->find();
			
			$cateInfo=$this->getCateInfo();
			$this->assign('cateInfo',$cateInfo);
			$this->assign('data',$cateArr);
			return $this->fetch('update');
		}
		//修改的执行页面
		public function edit(){
			$data=input('post.');
			//非空验证
			if(empty($data['cate_name'])){
				$this->error("分类名不能为空");die;
			}else{
				//修改的唯一性
			$editWhere=[
				['cate_name','=',$data['cate_name']],
				['cate_id','neq',$data['cate_id']],
			];

			$kkk=model('category')->where($editWhere)->find();
				if($kkk){
					$this->error('该分类已经存在,重新填写');
				};
			}
			

			

			$where=[
				['cate_id','=',$data['cate_id']]	
			];
			$res=model('category')->where($where)->update($data);
			if($res!==false){
				$this->success('编辑成功',url('category/index'));
			}else{
				$this->error('编辑失败',url('category/update'));
			}
		}


	 public  function changeValue(){
			$value=input('post._value');
			$field=input('post._field');
			$cate_id=input('post.cate_id');

			$cate_model =model('category');

			$where=[
				['cate_id','=',$cate_id]	
			];

			//print_r($where);die;
			$arr =[$field=>$value];
				//print_r($arr);die;
			$res=$cate_model->where($where)->update($arr);//受影响的行数1 0    flase
				//var_dump($res);die;
				if($res===false){
					echo "no";
				}else {
					echo "ok";
					}
		}





}
 