<?php

namespace app\admin\controller;

use think\Controller;

class Common extends Controller
{
    //防非法登录
	public function _initlize(){
		if(!session("?adminInfo")){
		$this->error('请先登录',url('login/login'));exit;  
		}
	}
	//获取分类的数据
		public function getCateInfo(){
			$cate_model=model('Category');
		$cateInfo=$cate_model->select()->toArray();  
		$cateInfo=getCateInfo($cateInfo);
		//print_r($cateInfo);
		  return $cateInfo;
		}

}
