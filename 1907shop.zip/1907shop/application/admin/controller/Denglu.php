<?php

namespace app\admin\controller;

use think\Controller;

class Denglu extends Controller
{
   function Denglu(){
	   // 临时关闭当前模板的布局功能 
	   $this->view->engine->layout(false); 
	  
	return 	$this->fetch('Denglu');
   }


   function loginDo(){
		$account=input('post.account');
		$pwd=input('post.pwd');
		
		
		$admin_model=model('admin');
		$adminInfo=$admin_model->find();
		if(!empty($adminInfo)){
			

				session('adminInfo',['id'=>$adminInfo['id'],'admin_logo'=>$adminInfo['admin_logo']]);
				$this->success('登录成功',url('student/create'));
			}else{
				$this->error('账号或密码失败',url('Denglu/Denglu'));
			}
		
   } 
	function quit(){
		session('adminInfo',null);
		$this->success('退出成功',url('Denglu/Denglu'));
	}
		
}
      
