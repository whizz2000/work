<?php

namespace app\admin\controller;

use think\Controller;

class Goods extends Common
{
     //商品的添加
	public function create(){
		//查询品牌的数据作为下拉菜单的值
		$brand_model=model('Brand');
		$brandInfo=$brand_model->select();
		//查询分类的数据作为下拉菜单的值
		$cateInfo=$this->getCateInfo();
		$this->assign('brandInfo',$brandInfo);
		$this->assign('cateInfo',$cateInfo);
		return $this->fetch('create');
	}
	
	
	public function save(){
		$data=input('post.');
		//dump($data);
		
		//商品图片
		$goods_img=$this->upload();
		if(empty($goods_img)){
			$this->error('文件上传有误');exit;
		}
		//echo $goods_img;die;
		$data['goods_img']=$goods_img;
		//商品相册
		  $goods_imgs=$this->uploads();
	
		/*if($_FILES['myfiles']['error'][0] != 0){
			$this->error("文件上传有误");
		}*/
	
		$data['goods_imgs']=$goods_imgs;
		//dump($data);die;
		$res=model('goods')->save($data);
			if($res){
				$this->success('添加成功','goods/index');
			}else{
				$this->error('添加失败');
			}
	}

	//单文件上传
	public function upload(){
		$file=request()->file('myfile');
		$info=$file->move('./static/goods_img');

		if($info){
			return '/static/goods_img/'.$info->getSaveName();
		}else{
			return false;
		}
	}
	//多文件上传
	public function uploads(){
		$files=request()->file('myfiles');
		
		$goods_imgs='';
		foreach($files as $file){
			$info = $file->move( './static/goods_imgs');
			if($info){
				$goods_imgs.='/static/goods_imgs/'.$info->getSaveName().'|';
			}else{
				continue;
			}
		}
		  return rtrim($goods_imgs,'|');

	}
	//商品的展示
	public function index(){ 
		//搜索的条件
		$query=input('get.');
		//print_r($query);
		$where=[];
		if(!empty($query['goods_name'])){
			$where[]=['goods_name','like','%'.$query['goods_name'].'%'];
		}
		if(!empty($query['brand_id'])){
			$where[]=['b.brand_id','=',$query['brand_id']];
		}
		if(!empty($query['min_price'])&&!empty($query['max_price'])){
			if($query['min_price']>$query['max_price']){
				$this->error("最小值不能大于最大值");
			}
		}
		if(!empty($query['min_price'])){
			$where[]=[
				'goods_price','>=',$query['min_price']
			];
		}
		if(!empty($query['max_price'])){
			$where[]=[
				'goods_price','<=',$query['max_price']
			];
		}


		/*if(!empty($query['min_price'])&&empty($query['max_price'])){
			$where[]=['goods_price','>=',$query['min_price']];
		}else if(empty($query['min_price'])&&!empty($query['max_price'])){
			$where[]=['goods_price','<=',$query['max_price']];
		}else if(!empty($query['min_price'])&&!empty($query['max_pricc'])){
			if($query['min_price']<$query['max_price']){
				$where[]=['goods_price','between',[$query['min_price'],$query['max_prices']]];
			}else{
				$this->error("最小价格不能大于最大价格");
			}
		
		}*/
		
		
		//查询品牌数据作为搜素的下拉菜单
		$bandInfo=model('Brand')->select();
		//查询分类的数据作为搜索的下拉菜单
		$cateInfo=$this->getCateInfo();
		
			
		$goods_model=model('goods');//model实例化
		//三标联查商品的数据
		$res=$goods_model
						->field("g.*,b.brand_name,c.cate_name")
						->alias('g')
						->join('brand b',"g.brand_id=b.brand_id")
						->join('category c',"g.cate_id=c.cate_id")
						->where($where)
						->paginate(8,false,['query'=>$query]);
		foreach($res as $k=>$v){
			$res[$k]['goods_imgs']=explode('|',$v['goods_imgs']);
		}
		$this->assign('brandInfo',$bandInfo);
		$this->assign('cateInfo',$cateInfo);
					//print_r($res->toArray());die;
					$this->assign('arr',$res);
					
		return $this->fetch('index');
	}
	//商品删除
	public function del(){
		$goods_id=input('get.goods_id');
		$res=model('goods')->where('goods_id','=',$goods_id)->delete();
		if($res){
			$this->success('删除成功','goods/index');
		}else{
			$this->error('删除失败');
		}
	}
	//商品的修改一的试图页面
	public function edit(){
		$goods_id=input('get.goods_id');
		//根据商品的id查询一条要修改的数据 作为表单的默认值
		$goods_model=model('Goods');
		$goodsInfo=$goods_model->where('goods_id','=',$goods_id)->find()->toArray();
		$goodsInfo['goods_imgs']=explode('|',$goodsInfo['goods_imgs']);
		//print_r($goodsInfo);exit;


		//查询品牌的数据作为下拉菜单的值
		$brand_model=model('Brand');
		$brandInfo=$brand_model->select();
		//查询分类的数据作为下拉菜单的值
		$cateInfo=$this->getCateInfo();
		$this->assign('brandInfo',$brandInfo);
		$this->assign('cateInfo',$cateInfo);
		$this->assign('goodsInfo',$goodsInfo);
		return $this->fetch();
	}
	//商品的修改二
		public function update(){
			$data=input('post.');
			//print_r($data);

			//验证


			$file=$_FILES['myfile'];//原声代码接图时不报错
			if($file['error']==0){
				$goods_img=$this->upload();
				$data['goods_img']=$goods_img;
			}

			$files=$_FILES['myfiles'];
			//print_r($files);die;
			if($files['error'][0]==0){
				$goods_imgs=$this->uploads();
				$data['goods_imgs']=$goods_imgs;
			}
			//print_r($data);die;
			$goods_model=model('Goods');
			$where=[
				['goods_id','=',$data['goods_id']]	
			];

			$res=$goods_model->where($where)->update($data);
				if($res){
					$this->success('修改成功',url('goods/index'));
				}else{
					$this->error('修改失败');
				}
		}
}
