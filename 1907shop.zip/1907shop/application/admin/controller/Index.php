<?php
namespace app\admin\controller;
use	think\Controller;
use think\Db;
class Index extends Common
{
    public function index()
    {
      return $this->fetch();
    }
	//登录验证
	/*public function check_index(){
		//echo 111;
		$email=input('email');
		$pasword=input('password');
//echo $email.'!!!'.$pasword;
		$where=[
			['account', '=', $email],
			['pwd', '=', $pasword]
		];
		//$res = Db::name('shop_admin')->where('account', '=', $email)
		//							->where('pwd', '=', $pasword)
		//							->find();
		$res = Db::name('shop_admin')->where($where)->find();
		if($res){
			$this->success('登录成功','admin/index/index');
		}else{
			$this->error('登录失败');
		}
		
	}*/

	public function test(){
		$adminInfo=session('adminInfo');
		print_r($adminInfo);
	}

	




}
