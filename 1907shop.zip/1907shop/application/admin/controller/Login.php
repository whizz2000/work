<?php

namespace app\admin\controller;

use think\Controller;

class Login extends Controller
{
   function login(){
	   // 临时关闭当前模板的布局功能 
	   $this->view->engine->layout(false); 
	  
	return 	$this->fetch('login');
   }


   function loginDo(){
		$account=input('post.account');
		$pwd=input('post.pwd');
		$code=input('post.code');//用户输入的验证码
		//验证验证码是否正确
		if(empty(captcha_check($code))){
			$this->error("验证码有误",url('login/login'));exit;
		}

			$where=[
				['account','=',$account]	
			];

		//
		$admin_model=model('admin');
		$adminInfo=$admin_model->where($where)->find();
		if(!empty($adminInfo)){
			if($adminInfo['pwd']==md5($pwd)){
				//修改当前用户的ip 时间
				//echo request()->ip();exit();
				$arr=['login_ip'=>request()->ip(),'login_time'=>time()];
				$wh=[
					['id','=',$adminInfo['id']]	
				];
				$admin_model->where($wh)->update($arr);

				session('adminInfo',['id'=>$adminInfo['id'],'account'=>$adminInfo['account'],'admin_logo'=>$adminInfo['admin_logo']]);
				$this->success('登录成功',url('index/index'));
			}else{
				$this->error('账号或密码失败',url('login/login'));
			}
		}else{
				$this->error('账号或密码失败',url('login/login'));
		}
   } 
	function quit(){
		session('adminInfo',null);
		$this->success('退出成功',url('login/login'));
	}
		
}
      
