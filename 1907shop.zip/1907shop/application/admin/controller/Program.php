<?php
namespace app\admin\controller;
use think\Controller;
class Program extends Controller{
	/** 添加的视图*/
	public  function create(){
		//写活下拉菜单
		$type_model=model('type');
		$typeInfo=$type_model->select();
		$this->assign('typeInfo',$typeInfo);
		//print_r($typeInfo);
		
		return $this->fetch();
	
	} 

	/** 节目的添加*/
	public function save(){
		$data=input('post.');
		//date(日期格式,时间戳)将时间戳转化为日期
		//strtotime()把日期改为时间戳
		$data['start_time']=strtotime($data['start_time']);
		$data['end_time']=strtotime($data['end_time']);

		//print_r($data);exit;
		$program_model=modeL('Program');
		$res=$program_model->save($data);
		//print_r($res);die;
		if($res){
			$this->success('添加成功',url('program/index'));
		}else{
			$this->error('添加失败');
		}
	}
	/** 列表展示*/
	public function index(){
		//写活下拉菜单
		$type_model=model('type');
		$typeInfo=$type_model->select();
		$this->assign('typeInfo',$typeInfo);

		//列表数据
		$program_model=model('Program');
		$programInfo=$program_model
			->alias('p')
			->join("type t","p.tid=t.tid")
			->select();
		//print_r($programInfo);exit;
		$this->assign('programInfo',$programInfo);
		return $this->fetch();
	}

	public function getProgramInfo(){
		$data=input('post.');
		print_r($data);
	}

	//删除
	public function del(){
		$program_id=input('get.program_id');
		$res=model('program')->where('program_id','=',$program_id)->delete();
		if($res){
			$this->success("删除成功",'program/index');
		}else {
			$this->error('删除失败');
		}
	}
}
?>