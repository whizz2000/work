<?php
namespace app\admin\controller;
use think\Controller;
class Student extends Common{
	//添加视图
	public function create(){
		//写活下拉菜单
		$class_model=model('Listen');
		$classInfo=$class_model->select();
		$this->assign('classInfo',$classInfo);
		return $this->fetch();
	}
	//视图添加
	public function save (){
		$data=input('post.');
		
		$studnet_model=model('student');
		
		//上传图片
		$myfile=$_FILES['myfile'];
		if($myfile['error']!=0){
			$this->error('文件上传有误');
		}else{
			$file=request()->file('myfile');
			$info=$file->move('./static/studentlogo');
			if(empty($info)){
				$this->error('文件上传有误');
			}
			$data['myfile']='/static/studentlogo/'.$info->getSaveName();
		}
		//var_dump($data);die;
		$res=$studnet_model->save($data);
		//var_dump($res);die;
		if($res){
			$this->success('添加成功','student/index');
		}else{
			$this->error('添加失败');
		}
	}
	//视图的展示页面
	public  function index(){
		$query=input('get.');
		
		$where=[];
		if(!empty($query['sname'])){
			$where[]=['sname','like',"%".$query['sname']."%"];
		}
		if(!empty($query['cid'])){
			$where[]=['s.cid','=',$query['cid']];
		}
		//dump($where);
		//写活下拉菜单
		$class_model=model('Listen');
		$classInfo=$class_model->select();
		$this->assign('classInfo',$classInfo);


		$student_model=model('student');
		$studentInfo=$student_model->alias('s')
								   ->join('listen l',"s.cid=l.cid")
									->where($where)
									->paginate(3,false,['query'=>$query]);
		$this->assign('studentInfo',$studentInfo);
		return $this->fetch();
	}
	//修改的展示页面
	public function edit(){
		$student_model=model('student');
		$update=input('post.');
		$res=$student_model->update($update);
		if($res){
			$this->success('修改成功','student/index');
		}else {
			$this->error('修改失败');
		}
	}
	//修改的执行页面
	public function update(){

		//写活下拉菜单
		$class_model=model('Listen');
		$classInfo=$class_model->select();
		$this->assign('classInfo',$classInfo);

		$sid=input('get.sid');
		$student_model=model('student');
		$studentInfo=$student_model->where('sid','=',$sid)->find();
		$this->assign('student',$studentInfo);
		return $this->fetch('edit');
	}
}
?>