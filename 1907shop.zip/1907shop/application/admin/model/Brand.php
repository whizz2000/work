<?php

namespace app\admin\model;

use think\Model;

class Brand extends Model
{
    protected $pk='brand_id';
}
