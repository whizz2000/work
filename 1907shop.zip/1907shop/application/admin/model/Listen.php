<?php

namespace app\admin\model;

use think\Model;

class Listen extends Model
{
    protected $pk='cid';
}
