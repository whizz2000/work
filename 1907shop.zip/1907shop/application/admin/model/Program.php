<?php

namespace app\admin\model;

use think\Model;

class Program extends Model
{
    protected $pk='program_id';
}
