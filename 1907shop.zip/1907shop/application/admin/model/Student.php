<?php

namespace app\admin\model;

use think\Model;

class Student extends Model
{
    protected $pk='sid';
}
