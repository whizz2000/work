<?php

namespace app\admin\model;

use think\Model;

class Type extends Model
{
    protected $pk='t_id';
}
