<?php

namespace app\common\model\admin;

use think\Model;

class Admin extends Model
{
    //
}
