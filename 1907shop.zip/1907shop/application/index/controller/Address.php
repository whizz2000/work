<?php
namespace app\index\controller;
use think\Controller;
class Address extends Common
{
	public function __contruct(){
		if(!$this->checkLogin()){
			$this->error('请先登录',url('login/login'));
		}
	}
	
	/**收货地址的列表/添加*/ 	
	public  function index(){
		
		$url=input('return _url');
		//查询所有的收货地址--列表展示
		$user_id=$this->getUserId();
		$where=[
			['user_id','=',$user_id],
			['is_del','=',1]
		];
		$address_model=model('Address');
		$addressInfo=$address_model->where($where)->select();
		$area_model=model('Area');
		foreach ($addressInfo as $k=>$v){
			$addressInfo[$k]['province']=$area_model->where('id',$v['province'])->value('name');
			$addressInfo[$k]['city']=$area_model->where('id',$v['city'])->value('name');
			$addressInfo[$k]['area']=$area_model->where('id',$v['area'])->value('name');
		}
		//print_r($addressInfo);die;
		//查询所有的省份作为第一个下拉菜单的值
		$provinceInfo=$this->getAreaInfo(0);
		$this->assign('provinceInfo',$provinceInfo);
		$this->assign('addressInfo',$addressInfo);
		

		return $this->fetch();
	}
	/** 获取区域信息*/
	public function getAreaInfo($pid){
		$area_model=model('Area');
		return $area_model->where('pid','=',$pid)->select();

	}
	public function getArea(){
		$id=input('post.id');
		$info = $this->getAreaInfo($id);
		echo json_encode($info);
	}
	/**添加 */
	public function save(){
		$data = input('post.');
		$user_id=$this->getUserId();
		$data['user_id']=$user_id;
		
		$address_model=model('Address');
	//判断当前添加的数据 是否要设置为默认
		if(!empty($data['is_default'])){
				$where=[
					['user_id','=',$user_id],
					['is_del','=',1]
				];
				$res=$address_model->where($where)->update(['is_default'=>2]);
		}
		$res=$address_model->save($data);
		if($res){
			successly('添加成功');
		}else{
			fail('添加失败');
		}
	}
	//设置为默认
	public function setDefault(){
		$address_id=input('get.address_id');
		//echo $address_id;die;获取设为默认的id
		//把所有人的default=2
		$user_id=$this->getUserId();
		$address_model=model('Address');
		$where=[
			['user_id','=',	$user_id],
			['is_del','=',1]
		];
		//开启事务
		$address_model->startTrans();
		$result1=$address_model->where($where)->update(['is_default'=>2]);//0 1false
		//把自己的is_default=1
		$result2=$address_model->where('address_id',$address_id)->update(['is_default'=>1]);//1
		if($result1!==false&&$result2){
			//提交
			$address_model->commit();
			$this->success('设置成功','address/index');
		}else {
			//回滚
			$address_model->rollback();
			$this->error('设置失败');
		}
	}

	/**编辑视图 */
	public  function edit(){
		$address_id=input('get.address_id');
		//根据收货地址的id 查询要修改的一条数据 作为表单的默认值
		$address_model=model('Address');
		$where=[
				['address_id','=',$address_id],
				['is_del','=',1]
			];
		$addressInfo=$address_model->where($where)->find();
		if(empty($addressInfo)){
			$this->error('非法操作',url('address/index'));exit;
		}
		//查询省份信息作为第一个下拉菜单的值
		$provinceInfo=$this->getAreaInfo(0);

		//查询市信息作为第二个下拉菜单的值
		$cityInfo=$this->getAreaInfo($addressInfo['province']);
		//查询区信息作为第三个下拉菜单的值
		$areaInfo=$this->getAreaInfo($addressInfo['city']);

		$this->assign('provinceInfo',$provinceInfo);
		$this->assign('cityInfo',$cityInfo);
		$this->assign('areaInfo',$areaInfo);
		$this->assign('addressInfo',$addressInfo);

		return $this->fetch();
	}
	/**修改 */
	public function update(){
		$data=input('post.');
		 $user_id=$this->getUserId();
		 $addressInfo=modle('Address');
		 if(!empty($data['is_default'])){
			$where=[
				['user_id','=',$user_id],
				['is_del','=',1]
			];
			$result = $address_model->where($where)->update(['is_default'=>2]);
		 }
		 $res =$address_model->where('address_id',$data['address_id'])->update($data);
		 if(res){
			 successly('修改成功');
		 }else{
			 fail('修改失败');
		 }
	}
	/**删除 */
	public function del(){
		$address_id=input('get.address_id');
		$address_model=model('Address');
		$res=$address_model->where('address_id','=',$address_id)->delete();
		if($res){
			$this->success('删除成功','address/index');
		}else{
			$this->error('删除失败');
		}
	}

} 

 