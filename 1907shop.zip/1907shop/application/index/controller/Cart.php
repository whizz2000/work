<?php
namespace app\index\controller;
use think\Controller;
class Cart extends Common{
	public function addCart (){
		$goods_id=input('post.goods_id');
		$buy_number=input('post.buy_number');

		if($this->checkLogin()){
			$this->addCartDb($goods_id,$buy_number);			
		}else{
			$this->addCartCookie($goods_id,$buy_number);
		}
		
	}
	/**加入购物车--到数据库*/
	public function addCartDb($goods_id,$buy_number){
		$user_id=$this->getUserId();
		//查询此用户是否买过此商品
		
		$where=[
				['user_id','=',$user_id],
				['goods_id','=',$goods_id],
				['cart_del','=',1]
			];
		$cart_model=model('Cart');
		$cartInfo = $cart_model->where($where)->find();
		//print_r($cartInfo);die;
		if(!empty($cartInfo)){
			//检测库存
			$result=$this->checkGoodsNum($goods_id,$buy_number,$cartInfo['buy_number']);
			//dump($result);die;
			if(empty($result)){
				fail('此商品购买数量已超过库存');
			}
			
			//累加 修改
			$res=$cart_model->where($where)->update(['buy_number'=>$cartInfo['buy_number']+$buy_number]);
				
		}else{
			//检测库存
			$result=$this->checkGoodsNum($goods_id,$buy_number);
			//dump($result);die;
			if(empty($result)){
				fail('此商品购买数量已超过库存');
			}
			//添加 
			$arr=['goods_id'=>$goods_id,'buy_number'=>$buy_number,'user_id'=>$user_id,'add_time'=>time()];
			$res=$cart_model->save($arr);			
		}
		if($res){
			successly(''); 

		}else{
			fail('此商品购买数量已超过库存');
		}
			 
		
	}
	/**加入购物车 --cookie*/
	public function addCartCookie($goods_id,$buy_number){
		$cartInfo=cookie('cartInfo');
		//判断cookie中是否有值
		
		if(!empty($cartInfo)){
			//检测库存

			//有值 判断此商品是否在cookie中出现过
			//出现过 累加
			//没出现
			if(array_key_exists($goods_id, $cartInfo)){
				//检测库存
				$result=$this->checkGoodsNum($goods_id,$buy_number,$cartInfo[$goods_id]['buy_number']);
			
					if(empty($result)){
					 fail('此商品购买数量已超过库存');
						}

					//累加
					
					$cartInfo[$goods_id]['buy_number']=$cartInfo[$goods_id]['buy_number']+$buy_number;
					$cartInfo[$goods_id]['add_time']=time();
			 }else {

			 		//检测库存
			 		$result=$this->checkGoodsNum($goods_id,$buy_number);
			
					if(empty($result)){
					 fail('此商品购买数量已超过库存');
						}

			 	   //添加
				 	  $cartInfo[$goods_id]=[
					'goods_id'=>$goods_id,'buy_number'=>$buy_number,'add_time'=>time()
				 ];
			 }
		}else {
			//检测库存
			 		$result=$this->checkGoodsNum($goods_id,$buy_number);
			
					if(empty($result)){
					 fail('此商品购买数量已超过库存');
						}

			//cookie没值 添加
			$cartInfo[$goods_id]=[
				'goods_id'=>$goods_id,'buy_number'=>$buy_number,'add_time'=>time()
			];
		}
		
			cookie('cartInfo',$cartInfo);
			successly('');

	}
	/**购物车列表*/
	public function cartList(){
		//判断用户是否登录
		if($this->checkLogin()){
			$cartInfo = $this->getCartIngoDb();
		}else {
			$cartInfo = $this->getCartIngoCookie();
		}
		
		$this->assign('cartInfo',$cartInfo);
		$this->getCateData();
		return $this->fetch('cart_list');
	}

	/**购物车列表中的数据--数据库*/
	public function getCartIngoDb(){
		$user_id=$this->getUserId();
		$where=[
			['user_id','=',$user_id],
			['cart_del','=',1]
		];
		$goods_model=model('Goods');
		$cartInfo=$goods_model
			->field("g.goods_id,goods_num,goods_name,goods_price,goods_img,buy_number")
			->alias('g')
			->join("Cart c","g.goods_id=c.goods_id")
			->where($where)
			->select();
			return $cartInfo;
	}
	/**购物车列表中的数据--Cookie*/
	public function getCartIngoCookie(){
		$cartInfo = cookie('cartInfo');
		if(!empty($cartInfo)){
			$add_time = array_column($cartInfo,'add_time');
			//print_r($cartInfo);exit;
			//dump($cartInfo);die;
			array_multisort($add_time,SORT_DESC,$cartInfo);
			$goods_model=model('Goods');
			foreach($cartInfo as $k=>$v){
				$arr=$goods_model
							->field('goods_name,goods_id,goods_price,goods_num,goods_img')
							->where("goods_id",$v['goods_id'])
							->find()
							->toArray();
							//print_r($arr);die;
							$cartInfo[$k]=array_merge($v,$arr);
			}
			//print_r($cartInfo);
			return $cartInfo;
		}
	}

	/**修改购买的数量*/
	public function changeByNumber(){
		$goods_id=input('post.goods_id');
		$buy_number=input('post.buy_number');
		if($this->checkLogin()){
			$result=$this->changeByNumberDb($goods_id,$buy_number);
			// dump($result);die;
		}else{
			$result=$this->changeByNumberCookie($goods_id,$buy_number);
		}
		if($result!==false){
			echo 'ok';
		}else {
			echo 'no';
		}
	}

	/**修改购买数量--数据库*/
	public function changeByNumberDb($goods_id,$buy_number){
		$cart_model=model('Cart');
		$user_id=$this->getUserId();
		$where=[
				['user_id','=',$user_id],
				['goods_id','=',$goods_id],
				['cart_del','=',1]

			];
			return $cart_model->where($where)->update(['buy_number'=>$buy_number]);
	}

	/**修改购买数量--cookie*/
	public function changeByNumberCookie($goods_id,$buy_number){
		$cartInfo = cookie('cartInfo');
		$cartInfo[$goods_id]['buy_number']=$buy_number;
		cookie('cartInfo',$cartInfo);
		return true;
	}
	/**获取小计*/
	public function getTotal(){
		$goods_id=input('post.goods_id');
		//在商品表中获取单价
		$goods_model=model('Goods');
		$goods_price=$goods_model->where('goods_id','=',$goods_id)->value('goods_price');
		if($this->checkLogin()){
			$total=$this->getTotalDb($goods_id,$goods_price);
		}else {
			$total=$this->getTotalCookie($goods_id,$goods_price);
		}
		echo $total;
	}
	/**获取小计 --数据库*/
	public function getTotalDb($goods_id,$goods_price){
		//购买数量
		$user_id=$this->getUserId();
		$where=[
				['user_id','=',$user_id],
				['goods_id','=',$goods_id],
				['cart_del','=',1]
			];
			$cart_model=model('Cart');
			$buy_number=$cart_model->where($where)->value('buy_number');
			//dump($buy_number);die;
			return $goods_price*$buy_number;

	}
	/**获取小计--cookie*/
	public function getTotalCookie($goods_id,$goods_price){
		//在cookie中根据商品id 得到购买数量
		$cartInfo = cookie('cartInfo');
		$buy_number=$cartInfo[$goods_id]['buy_number'];
		//print_r($cartInfo);die;
		return  $goods_price*$buy_number;
	}
	/**获取总价*/
	public function getCount(){
		$goods_id=input('post.goods_id');
		//echo $goods_id;die;
		
		if($this->checkLogin()){
			$money=$this->getCountDb($goods_id);
		}else {
			$this->getCountCookie($goods_id);
		}
		//echo $money;
	}
	/**获取总价 --数据库*/
	public function getCountDb($goods_id){
		//根据商品id 查询总价和数量
		$user_id=$this->getUserId();
		$where=[
				['user_id','=',$user_id],
				['c.goods_id','in',$goods_id],
				['cart_del','=',1]
			];
			$cart_model=model('Cart');
			$info =$cart_model
				->field('buy_number,goods_price')
				->alias("c")
				->join("goods g","c.goods_id=g.goods_id")
				->where($where)
				->select();
		$money=0;
		foreach($info as $k=>$v){
			$money+=$v['goods_price']*$v['buy_number'];
		}
		echo $money;

	}
	/**获取总价--cookie*/
	public function getCountCookie($goods_id){
		$goods_id=explode(',',$goods_id);

		$goods_model=model('Goods');
		$money=0;
		//根据商品的品id 查询每一件商品的单价和数量
		$cartInfo=cookie('cartInfo');
		//print_r($cartInfo);die;
		foreach($cartInfo as $k=>$v){
			if(in_array($k,$goods_id)){
				$goods_price=$goods_model->where('goods_id',$k)->value('goods_price');
				$money+=$v['buy_number']*$goods_price;
			}
		}
			return  $money;
	}
	
	/**购物车数据删除*/ 
	public function cartDel(){
		$goods_id=input('goods_id');
		if($this->checkLogin()){
			$res=$this->cartDelDb($goods_id);
		}else{
			$res=$this->cartDelCookie($goods_id);
		}
		if($res){
			successly('');
		}else {             
			fail('删除失败');
		}
	} 
		
	

	/**购物车数据删除--数据库*/
	public function cartDelDb($goods_id){
		$cart_model=model('Cart');
		$user_id=$this->getUserId();
		$where=[ 
				['user_id','=',$user_id],
				['goods_id','in',$goods_id],
			];
			return $cart_model->where($where)->update(['cart_del'=>2]);
	} 
	/**购物车数据删除--cookie*/
	public function cartDelCookie($goods_id){
		$cartInfo=cookie('cartInfo');
		if(substr_count($goods_id,',')>0){
			$goods_id=explode(',',$goods_id);
			//批删
			foreach($cartInfo as $k=>$v){
				if(in_array($k, $goods_id)){
					unset($cartInfo[$k]);
				}
			}
		}else {
			//单删
			unset($cartInfo[$goods_id]);
		}
		cookie('cartInfo',$cartInfo);
		
		return true;
	}
	/**点击确认结算*/
	
	public function test(){
		$cartInfo=cookie('cartInfo');
		print_r($cartInfo);
	}
	
}






?>