<?php

namespace app\index\controller;

use think\Controller;

class Common extends Controller
{
    /*获取导航以及左侧的分类*/
	public function getCateData(){
				/*导航数据*/
		
		$cate_model=model('Category');
		$where=[
			['cate_nav_show','=',1]	
		];
		$navInfo=$cate_model->where($where)->select();
		


		/*左侧的数据分类*/
		$cateInfo=$cate_model->select()->toArray();
		//print_r($cateInfo);die;
		$cateInfo=getCateInfo($cateInfo,0);
		//print_r($cateInfo);die;

	
		$this->assign('cateInfo',$cateInfo);
		$this->assign('navInfo',$navInfo);
	}

	/**检测是否登录*/
	public function checkLogin(){
		return session('?userInfo');
	}
	/**获取用户Id*/
	public function getUserId(){
		return session('userInfo.user_id');
	}
	/**检测库存*/
	public function checkGoodsNum($goods_id,$buy_number,$already_number=0){
		//根据商品id 查询到此商品的库存
		$goods_model=model('Goods');
		$goods_num=$goods_model->where('goods_id',$goods_id)->value('goods_num');
		if(($buy_number+$already_number)<=$goods_num){
			return true;
		}else{
			return false;
		}
	}
}
