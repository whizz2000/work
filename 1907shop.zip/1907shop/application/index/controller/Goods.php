<?php
namespace app\index\controller;
use think\Controller;
class Goods extends Common{
	/**商品列表*/
	public function goodsList(){
		//接收分类id
		$cate_id=input('get.cate_id');
		$where=[];
		
		if(!empty($cate_id)){
			//获取当前分类id下所有子类的id
			$cate_modle=model('Category');
			$cateInfo=$cate_modle->select()->toArray();
			
			$c_id=getCateId($cateInfo,$cate_id);//获取所有cate_id下的子类
			$where[]=['cate_id','in',$c_id];
			cookie('c_id',$c_id);
		}else {
			cookie('c_id',null);
		}
		//print_r($where);
		
		//1.品牌数据
		$goods_model=model('Goods');
		$brand_id=$goods_model->where($where)->column('brand_id');
		$brand_id=array_unique($brand_id);
		$brand_model=model('Brand');
		$brandWhere=[
			['brand_id','in',$brand_id]		
		];
		$brandInfo=$brand_model->where($brandWhere)->select();
		//print_r($brandInfo);exit;                                                                                                                                                                                                                                          

		//2.价格区间
		$max_price=$goods_model->where($where)->value("max(goods_price)");
		$priceInfo=$this->getPriceSection($max_price);
		
		//3.商品+分页 数据
		$p=1;
		$page_num=4;
		$goodsInfo=$goods_model
			->field('goods_id,goods_name,goods_price,goods_img,goods_score')
			->where($where)
			->page($p,$page_num)
			->select();

		$count=$goods_model
					->where($where)
					->count();
		//分页类
		$page_count=ceil($count/$page_num);
		//echo $count;die;
		$str="";
		for($i=1;$i<=$page_count;$i++){
			if($i==$p){
				$str.="<a href='javascript:;' class='page cur'>".$i."</a>";
			}else{
				$str.="<a href='javascript:;' class='page'>".$i."</a>";
			}
			
		}
		//获取浏览历史信息
		 
			//判断是否已经登录
			if($this->checkLogin()){
				$historyInfo=$this->getHistoryDb();
			}else {
				$historyInfo=$this->getHistoryCookie();

			}
		$this->getCateData();//获取左侧分类信息
		$this->assign('brandInfo',$brandInfo);
		$this->assign('priceInfo',$priceInfo);
		$this->assign('goodsInfo',$goodsInfo);
		$this->assign('str',$str);
		$this->assign('historyInfo',$historyInfo);
		return $this->fetch();
	}
	/**获取浏览历史记录信息--数据库*/
	public function getHistoryDb(){
			//查询浏览历史记录表根据用户Id 时间倒序排序 得到商品的Id
			$history_model = model('History');
			$user_id=$this->getUserId();
			$goods_id=$history_model->where('user_id',$user_id)->order('look_time','desc')->column('goods_id');
			$goods_id=array_unique($goods_id);
			$goods_id=array_slice($goods_id,0,4);
			//print_r($goods_id);die;
			if(!empty($goods_id)){
					$goodsInfo=$this->getHistoryGoods($goods_id);
					return $goodsInfo;
				}else {
					return false ;
				}
	} 
	/**获取浏览历史记录信息--cookie*/
	public function getHistoryCookie(){
			$data=cookie('historyInfo');
			//print_r($data);
			if(!empty($data)){
				$data=array_reverse($data);
				$goods_id=[];
				foreach ($data as $key => $v) {
					$goods_id[]=$v['goods_id'];
				}
			$goods_id=array_unique($goods_id);
			//$goods_id=array_slice($goods_id);
			//print_r($goods_id)
			$goodsInfo=$this->getHistoryGoods($goods_id);
			return $goodsInfo;
		}else {
			return false;

		}
	}
	/**获取浏览的商品数据*/
	public function getHistoryGoods($goods_id){
		$goods_model=model('Goods');
		$where=[
				['goods_id','in',$goods_id]
			];
		$goods_id=implode(',', $goods_id);
		//echo $goods_id;die;
		//dump($goods_id);die;
		$exp= new \think\db\Expression("field(goods_id,$goods_id)");
		$goodsInfo=$goods_model->where($where)->order($exp)->select();
		//print_r($goodsInfo);die;
		return $goodsInfo;
	}

	/**获取价格区间*/
	public function getPriceSection($max_price){
		$price=$max_price/7;
		$priceInfo=[];
		for($i=0;$i<=6;$i++){
			$start=$i*$price;
			$end=($i+1)*$price-0.01;
			$priceInfo[]=number_format($start,2).'-'.number_format($end,2);			
		}
		$priceInfo[]=$max_price.'及以上';
		return $priceInfo;
		
	}
	/**重新获取商品数据++页码*/
	
	public function getGoodsInfo(){
		 $brand_id=input('post.brand_id');
		 $goods_price=input('post.goods_price');
		 $field=input('post.field');
		 $c_id=cookie('c_id');
		 $p=input('post.p');
		//处理条件
				$where=[];
				if(!empty($brand_id)){
					$where[]=['brand_id','=',$brand_id];
				}

				if(!empty($goods_price)){
					if(substr_count($goods_price,'-')>0){
						//区间
						$goods_price=str_replace(',','',$goods_price);
						//把字符串切割成数组 
						$goods_price=explode('-',$goods_price);
						//print_r($goods_price);die;
						$where[]=['goods_price','between',$goods_price];
					}else{
						$goods_price=(float)$goods_price;//强制转化  做运算时会自动转化
						$where[]=['goods_price','>=',$goods_price];
					}
				}
			
				if(!empty($field)){
					$where[]=[$field,'=',1];
				}

				if(!empty($c_id)){
					$where[]=['cate_id','in',$c_id];
				}
				
				//查询商品数据
				$goods_model=model('Goods');
				
				$page_num=4;
				$goodsInfo=$goods_model
					->field('goods_id,goods_name,goods_price,goods_img,goods_score')
					->where($where)
					->page($p,$page_num)
					->select();
					
				$count=$goods_model
							->where($where)
							->count();
				
				$page_count=ceil($count/$page_num);
				//echo $count;die;
				$str="";
				for($i=1;$i<=$page_count;$i++){
					if($i==$p){
						$str.="<a href='javascript:;' class='page cur'>".$i."</a>";
					}else{
						$str.="<a href='javascript:;' class='page'>".$i."</a>";
					}
				}
				$this->assign('goodsInfo',$goodsInfo);
				$this->assign('str',$str);
				$this->view->engine->layout(false);
				return $this->fetch('div');

	}

	/**商品详情页*/
	public function product(){
		//接收商品id
		$goods_id=input('get.goods_id');
		if(empty($goods_id)){
			$this->error('操作有误');exit;
		}
		//根据商品id查询一条数据
			$goods_model=model('goods');
			$goodsInfo=$goods_model->where('goods_id',$goods_id)->find();
			if(empty($goodsInfo)){
				$this->error('操作有误');exit;
			}
		$goodsInfo['goods_imgs']=explode('|',$goodsInfo['goods_imgs']);
		
		//浏览历史记录
			//判断session中是否有值
		if($this->checkLogin()){
			//已经登陆 把商品id 用户id 浏览时间入库
			$this->saveHistoryDb($goods_id);
		}else{
			//未登录
			$this->saveHistoryCookie($goods_id);
		}
		
		$this->getCateData();
		$this->assign('goodsInfo',$goodsInfo);
		return $this->fetch();
	}
	/**存储浏览历史记录--数据库*/
	public function saveHistoryDb($goods_id){
		$user_id=$this->getUserId();
		$arr = ['goods_id'=>$goods_id,'user_id'=>$user_id,'look_time'=>time()];
		$history_modle=model('History');
		$history_modle->save($arr);
	}
	/**存储浏览历史记录--Cookie*/
	public function saveHistoryCookie($goods_id){
		//去出cookie的值
		$historyInfo=cookie('historyInfo');
		$historyInfo[]= ['goods_id'=>$goods_id,'look_time'=>time()];
			
		cookie('historyInfo',$historyInfo );
	}

	
	/**获取价格*/
	public function getPrice(){
		$brand_id=input('post.brand_id');
		$c_id=cookie('c_id');
		//print_r($c_id);die;
		if(!empty($brand_id)){
			$where[]=['brand_id','=',$brand_id];
		}
		if(!empty($c_id)){
			$where[]=['cate_id','in',$c_id];
		}
		$goods_model=model('Goods');
		$max_price=$goods_model->where($where)->value("max(goods_price)");
		//echo $max_price;die;
		$priceInfo=$this->getPriceSection($max_price);

		$this->view->engine->layout(false);
		$this->assign('priceInfo',$priceInfo);
		return $this->fetch("a");
	}
	/**测试 cookie*/
	function test(){
		$historyInfo=cookie('historyInfo');
		print_r($historyInfo);
		

	}

}
?>