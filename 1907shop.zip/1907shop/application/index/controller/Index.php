<?php
namespace app\index\controller;
use think\Controller;
class Index extends Common
{
    public function index()
    {

		/*获取一楼数据*/
		$cate_id=1;
		$floorInfo=$this->getFloorInfo($cate_id);
	    $this->assign('floorInfo',$floorInfo);
	 	$this->getCateData();
		//dump($floorInfo);
		return $this->fetch();
    }
	public function getFloorInfo($cate_id){
		//顶级分类
		$cate_model=model('Category');
		$where=[
			['cate_id','=',$cate_id]	
		];
		$floorInfo['topInfo']=$cate_model->where($where)->find();
		//print_r($topInfo);die;
		//二级分类
		$floorInfo['sonInfo']=$cate_model->where('parent_id',$cate_id)->select();
		//print_r($sonInfo);die;
		//顶级分类下的商品数据
		$goods_model=model('Goods');
		$cateInfo=$cate_model->select();
		$c_id=getCateId($cateInfo,$cate_id);
		//print_r($c_id);die;
		$goodsWhere=[
			['cate_id','in',$c_id]	
		];
	$floorInfo['goodsInfo']=$goods_model->where($goodsWhere)->limit(8)->select();
		// print_r($goodsInfo);die;
	return $floorInfo;
	}

	/** 获取下一楼数据*/
	public function getMore(){
		$cate_id=input('post.cate_id');
		$num=input('post.num');
		$num=$num+1;

		$cate_model=model('Category');
		$where=[
			['parent_id','=',0],
			['cate_id','>',$cate_id]
		];
		$cate_id=$cate_model->where($where)->value("min(cate_id)");
		 //echo $cate_model->getLastSql();
		//echo $cate_id;exit;
		$floorInfo=$this->getFloorInfo($cate_id);//数组
		$this->assign('floorInfo',$floorInfo);
		$this->assign('num',$num);

		//临时关闭layout
		$this->view->engine->layout(false);
		return $this->fetch('div');
	}

} 
