<?php
namespace app\index\controller;
use think\Controller;
class Login extends Common{
	/*public function test(){
	 $res=sendEmail('1399442426@qq.com','验证码','您的验证码是123456');
	 var_dump($res);

	}

	public function test1(){
		$res=sendSms('13236941316','521521');
		var_dump($res);
	}*/

	//登录的视图
	public function login(){
		// 临时关闭当前模板的布局功能 
		$this->view->engine->layout(false);
		return $this->fetch();
	}

	public function loginDo(){
		 $account  = input('post.account');
		 $user_pwd = input('post.user_pwd');
		
		$time=time();
		//判断
		if(substr_count($account,'@')>0){
			$where[]=['user_email','=',$account];
		}else {
			$where[]=['user_tel','=',$account];
		}
		$user_model=model('User');
		$userInfo=$user_model->where($where)->find();
		if(!empty($userInfo)){
			//取出错误次数 最后一次错误时间
			$error_num=$userInfo['error_num'];
			$last_error_time=$userInfo['last_error_time'];
			$user_id=$userInfo['user_id'];
			if($userInfo['user_pwd']==md5($user_pwd)){
				
				$res=$user_model->where('user_id',$user_id)->update(['error_num'=>0,'last_error_time'=>null]);
				//把用户的id 账号存入session中
				session('userInfo',['user_id'=>$userInfo['user_id'],'account'=>$account]);

				//同步浏览历史记录 (封装)
				$this->asyncHistory();
				//同步购物车数据
				$this->asyncCart();
				//提示登录成功 跳转路径
				$this->success('登录成功',url('index/index'));
			}else{
				if(($time-$last_error_time)>=3600){
					//清零 错误时间改为null 错误次数+1
					//错误次数改为1 错误时间改为当前时间


					$res=$user_model->where('user_id',$user_id)->update(['error_num'=>1,'last_error_time'=>$time]);
					if($res){
						echo '密码错误,还有2次机会';exit;
					}
				}
				if($error_num>=3){
					$min=60-ceil(($time-$last_error_time)/60);
					echo "账号已锁定,请于".$min."分钟之后登录";exit;
				}else{
					$res=$user_model->where('user_id',$user_id)->update(['error_num'=>$error_num+1,'last_error_time'=>$time]);
					if($res){
						echo '密码错误,还有'.(3-($error_num+1)).'次机会';
					}
				}
				
			}
		}else{
			echo "账号有误";
		}
	}
	//注册的视图 
	public function register(){
		// 临时关闭当前模板的布局功能 
		$this->view->engine->layout(false);
		return $this->fetch();
	}
	//发送邮箱验证码
	public function sendEmailCode(){
		$email=input('post.email');
		$user_model=model('User');
		//echo $email;
		//验证邮箱格式
		$reg='/^[0-9a-z]{6,16}@[0-9a-z]{1,4}\.com$/';
	    
		 //验证邮箱非空
		if(empty($email)){
			fail('邮箱必填');
		}else if(!preg_match($reg,$email)){
			fail('邮箱格式有误');
		}else {
			//验证邮箱是否已经被注册
			$where=[
				['user_email','=',$email]	
			];
			$count=$user_model->where($where)->count();
			if($count>0){ 
				fail('此邮箱已经被注册');
			}
		}
		//随机生成六位的验证码
		$code=rand(100000,999999);
		$body="尊敬的用户,您的验证码为".$code.",五分钟内输入有效,请勿泄露";
		$res=sendEmail($email,'验证码',$body);
		//var_dump($res);
		if(!empty($res)){
			$emailInfo=['email'=>$email,'code'=>$code,'send_time'=>time()];
			cookie('emailInfo',$emailInfo);
			successly('发送成功');
			
		}else{
			
			fail('发送失败');
		}
		
	}
	
	//发送短信验证码
	public function sendTelCode(){
		 $tel=input('post.tel');
		
		$user_model=model('User');
		
		//验证电话格式
		//$reg='/^[1]{1}[0-9]{10}$/';
		$reg = "/^[1]{1}[0-9]{10}$/";
	    
		 //验证电话非空
		if(empty($tel)){
			fail('电话必填');
		} 
		if(!preg_match($reg,$tel)){
			fail('电话格式有误');
		}
		//验证电话是否已经被注册
		$count=$user_model->where('user_tel','=',$tel)->count();
			if($count>0){
				fail('此电话已经被注册');
			}
		
		//随机生成六位的验证码
		$code=rand(100000,999999);
		
		$res=sendSms($tel,$code);
		//var_dump($res);
		if(!empty($res)){
			$telInfo=['tel'=>$tel,'code'=>$code,'send_time'=>time()];
			cookie('telInfo',$telInfo);
			successly('发送成功');
			
		}else{
			
			fail('发送失败');
		}
		
	}
		
	

	//执行表单提交
	public function registerDo(){
		$data=input('post.');
		$user_model=model('User');
		if(array_key_exists('user_email',$data)){
			$emailInfo=cookie('emailInfo');
			if(empty($emailInfo['code'])){
			$this->error('请先获取验证码');die;
			}	
			
			//验证邮箱

		$reg='/^[0-9a-z]{6,16}@[0-9a-z]{1,4}\.com$/';
	    
		 //验证邮箱非空
		if(empty($data['user_email'])){
			$this->error('邮箱必填');exit;
		}else if(!preg_match($reg,$data['user_email'])){
			$this->error('邮箱格式有误');exit;
		}else {
			//验证邮箱是否已经被注册
			$where=[
				['user_email','=',$data['user_email']]	
			];
			$count=$user_model->where($where)->count();
			if($count>0){ 
				$this->error('此邮箱已经被注册');exit;
			}else if($emailInfo['email']!=$data['user_email']){
				//cookie的邮箱和注册的邮箱一致? 此邮箱没有被注册过
				$this->error('发送验证码邮箱和注册邮箱不一致');exit;
			}
		}
		//验证 验证码
			if(empty($data['user_code'])){
				$this->error('验证码必填');exit;
			}else if($emailInfo['code']!=$data['user_code']){
				$this->error('验证码有误');exit;
			}else if((time()-$emailInfo['send_time'])>300){
				$this->error('验证码已失效,五分钟内验证有效');exit;
			}
			
		}else{
				$telInfo=cookie('telInfo');
				if(empty($telInfo['code'])){
				$this->error('请先获取验证码');die;
				}
				//验证电话号码
			$reg='/^1[0-9]{10}$/';

			 //验证电话非空
			if(empty($data['user_tel'])){	
				$this->error('电话必填');exit;
			}else if(!preg_match($reg,$data['user_tel'])){	
				$this->error('电话格式有误');exit;
			}else {
				//验证电话是否已经被注册
				$where=[
					['user_tel','=',$data['user_tel']]	
				];
				$count=$user_model->where($where)->count();
				if($count>0){ 	
					$this->error('此电话已经被注册');exit;
				}else if($telInfo['tel']!=$data['user_tel']){
					//cookie的电话和注册的电话一致? 此电话没有被注册过
					$this->error('发送验证码电话和注册电话不一致');exit;
				}
			}
							

		}

		//验证密码
			if(empty($data['user_pwd'])){
				$this->error('密码必填');
			}
			//验证确认密码
			$data['user_pwd']=md5($data['user_pwd']);
			$data['creat_time']=time();
			
			
			$result=$user_model->save($data);
			if($result){
				echo "注册成功";
			}else{
				echo "注册失败";
			}

	}



	/*public function test(){
		$info=cookie('telInfo');
		print_r($info);

	}
	public function test1(){
		$info=cookie('emailInfo');
		print_r($info);

	}*/

	//同步浏览历史记录
	public function asyncHistory(){
		//取出cookie的数据
		$historyInfo=cookie('historyInfo');
			//print_r($historyInfo);
			if(!empty($historyInfo)){
				$user_id=$this->getUserId();
				//添加到浏览历史表中
				foreach($historyInfo as $k=>$v){
					$historyInfo[$k]['user_id']=$user_id;
					}
					$history_modle=model('History');
					$res=$history_modle->saveAll($historyInfo);
					if($res){
						cookie('historyInfo',null);
					}
				}	
	}
	//同步购物车数据
	public function asyncCart(){
		//取出cookie的数据
		$cartInfo=cookie('cartInfo');
		if(!empty($cartInfo)){
			//取出用户id
			////取出用户id
		$user_id=$this->getUserId();
		$cart_model=model('Cart');
		foreach ($cartInfo as $k=>$v){
			$where=[
					['user_id','=',$user_id],
					['goods_id','=',$v['goods_id']]
				];
			$arr=$cart_model->where($where)->find();
			if(!empty($arr)){
				//检测库存
					$result=$this->checkGoodsNum($v['goods_id'],$v['buy_number'],$arr['buy_number']);
					//dump($result);die;
					if(empty($result)){
						continue;
					}
				//累加
				$res=$cart_model->where($where)->update(['buy_number'=>$arr['buy_number']+$v['buy_number'],'add_time'=>$v['add_time']]);
				//跳过本次循环进行下一次循环
				if(!$res){
					continue;
				}
			}else{
				//检测库存
				$result=$this->checkGoodsNum($v['goods_id'],$v['buy_number']);
				//dump($result);die;
				if(empty($result)){
					fail('此商品购买数量已超过库存');
				}
				//添加
				$v['user_id']=$user_id;
				$res=$cart_model->insert($v);
				if(!$res){
					continue;
				}
			}
		}
		//清除cookie中的值
		cookie('cartInfo',null);
			
		}
		
	}

}







?>