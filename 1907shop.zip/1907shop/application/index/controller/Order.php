<?php
namespace app\index\controller;
use think\Controller;
use think\facade\Config;
class Order extends Common
{
	/**确认结算*/
	public function confirmOrder(){
		//判断用户是否登录
		if(!$this->checkLogin()){
			$this->error('请先登录',url('login/login'));
		}
		//接收商品id
		$goods_id=input('get.goods_id');
		if(empty($goods_id)){
			$this->error('非法操作',url('index/index'));
		}
		//根据商品id 查询购物车选中的商品
			
		$user_id=$this->getUserId();
		$where=[
			['user_id','=',$user_id],
			['cart_del','=',1],
			['g.goods_id','in',$goods_id]
		];
		$goods_model=model('Goods');
		$goodsInfo=$goods_model
			->field("g.goods_id,goods_score,goods_num,goods_name,goods_price,goods_img,buy_number")  
			->alias('g')
			->join("Cart c","g.goods_id=c.goods_id")
			->where($where)
			->select();
			
		//根据商品的id 查询商品的单价和数量
		$user_id=$this->getUserId();
		$where=[
				['user_id','=',$user_id],
				['c.goods_id','in',$goods_id],
				['cart_del','=',1]
			];
			$cart_model=model('Cart');
			$info =$cart_model
				->field('buy_number,goods_price')
				->alias("c")
				->join("goods g","c.goods_id=g.goods_id")
				->where($where)
				->select();
		$count=0;
		foreach($info as $k=>$v){
			$count+=$v['goods_price']*$v['buy_number'];
		}
		//获取收货地址的信息
		$user_id=$this->getUserId();
		$where=[
			['user_id','=',$user_id],
			['is_del','=',1]
		];
		$address_model=model('Address');
		$addressInfo=$address_model->where($where)->select()->toArray();
		$area_model=model('Area');
		foreach ($addressInfo as $k=>$v){
			$addressInfo[$k]['province']=$area_model->where('id',$v['province'])->value('name');
			$addressInfo[$k]['city']=$area_model->where('id',$v['city'])->value('name');
			$addressInfo[$k]['area']=$area_model->where('id',$v['area'])->value('name');
		}
		
		$this->assign('goodsInfo',$goodsInfo);
		$this->assign('addressInfo',$addressInfo);
		$this->assign('count',$count);
		$this->assign('goods_id',$goods_id);
		$this->getCateData();
		return  $this->fetch();  
	}
	/**提交订单 */
	public function submitOrder(){
		//接收商品id  收货地址的id 支付方式 订单留言
		$goods_id=input('get.goods_id');
		$address_id=input('get.address_id');
		$pay_type=input('get.pay_type');
		$order_talk=input('get.order_talk');
		
		//事务 订单号 try catch
		$order_model=model('Order');
		//开启事务
		$order_model->startTrans();
		try{
			//1.添加订单表数据
			if(empty($goods_id)){
				throw new \Exception('至少选择一件商品');		
			}
			$user_id=$this->getUserId();
			$orderInfo['order_no']=time().rand(1000,9999);
			$orderInfo['user_id']=$user_id;

			$where=[
				['user_id','=',$user_id],
				['c.goods_id','in',$goods_id],
				['cart_del','=',1]
			];
			$cart_model=model('Cart');
			$info =$cart_model
				->field('buy_number,goods_price,goods_score,goods_name,goods_img,c.goods_id')
				->alias("c")
				->join("goods g","c.goods_id=g.goods_id")
				->where($where)
				->select()->toArray();
				if(empty($info)){
					throw new \Exception('此订单中的商品信息错误');
				}
		$money=0;
		$score=0;
		foreach($info as $k=>$v){
			$money+=$v['goods_price']*$v['buy_number'];
			$score+=$v['goods_score']*$v['buy_number'];
		}
			$orderInfo['order_amount']=$money;//总金额
			$orderInfo['order_score']=$score;//总积分
			$orderInfo['pay_type']=$pay_type;//支付类型
			$orderInfo['order_talk']=$order_talk;//支付留言
			$orderInfo['ctime']=time();//订单的创建时间
			//print_r($orderInfo);die;
			$res1= $order_model->save($orderInfo);
			if(empty($res1)){
				//回滚
				$order_model->rollback();
				throw new \Exception('订单数据添加失败');
			}
				//获取order表的主键
			$order_id=$order_model->order_id;
			//2.添加收货地址表
			$address_model=model('Address');
			$orderAddress['user_id']=$user_id;
			$orderAddress['order_id']=$order_id;
			if(empty($address_id)){
				throw new \Exception('收货地址必须选一项');
			}
			$addressWhere=[
				['address_id','=',$address_id]
			];

			$addressInfo=$address_model->where($addressWhere)->find(); 
			if(empty($addressInfo)){
				//回滚
				
				throw new \Exception('非法操作收货地址');
			}
			$addressInfo = $addressInfo->toArray();
			$addressInfo['order_id']=$order_id;
			$order_address=model('OrderAddress');	
			$res2=$order_address->save($addressInfo);
				if(empty($res2)){
					//回滚
					$order_model->rollback();
					throw new \Exception('订单收货地址添加失败');
				}

			//3.添加订单的商品信息
			foreach ($info as $k=>$v){
				$info[$k]['user_id']=$user_id;
				$info[$k]['order_id']=$order_id;
			}
				$order_detail=model('OrderDetail');
				$res3=$order_detail->saveAll($info);
				if(empty($res3)){
					//回滚
					$order_model->rollback();
					throw new \Exception('订单商品添加失败');
				}

			//4.清除购物车
			$cartWhere=[
				['user_id','=',$user_id],
				['cart_del','=',1],
				['goods_id','in',$goods_id]
			];
			$res4 = $cart_model->where($cartWhere)->update(['cart_del'=>2]);
			//$res4=false;
			
			if(empty($res4)){
				//回滚
				$order_model->rollback();
				throw new \Exception('清除购物车中已经购买的商品失败');
			}
			
 
			//5.修改商品表中已经购买商品的库存
			$goods_model=model('Goods');
			foreach($info as $k=>$v){
				$res5=$goods_model->where('goods_id',$v['goods_id'])->setDec('goods_num',$v['buy_number']);
				if(empty($res5)){
					//回滚
				$order_model->rollback();
				
				throw new \Exception('商品库存修改失败');
				}
			}
			//提交
			$order_model->commit();
			//echo  "okok";
			echo "<script>alert('订单提交成功');location.href='".url('order/orderSuccess')."?order_id=$order_id'</script>";
		}catch(\Exception $e){
			$font=$e->getMessage();
			$this->error($font);
		}



	}
	/**订单提交成功*/
	public function orderSuccess(){
		$order_id=input('get.order_id');
		//根据订单id 查询此订单的一条数据
		$order_model=model('Order');
		$user_id=$this->getUserId();
		$where=[
				['user_id','=',$user_id],
				['order_id','=',$order_id]
			];
		$orderInfo=$order_model->where($where)->find();
		$this->getCateData();
		$this->assign('orderInfo',$orderInfo);
		return $this->fetch ();
	}
	/**订单支付*/
	public function payMoney(){
		$order_id=input('get.order_id');
		if(empty($order_id)){
			$this->error('非法操作');exit;
		}
		//根据订单中的Id 查询次订单中的一条数据
		$order_model=model('Order');
		$user_id=$this->getUserId();
		$where=[
				['user_id','=',$user_id],
				['order_id','=',$order_id]
			];
		$orderInfo=$order_model->where($where)->find();
		if(empty($orderInfo)){
			$this->error('非法操作');exit;
		}
		//支付
			$config= Config::get('alipay.');
			
			require_once '../extend/alipay/pagepay/service/AlipayTradeService.php';
			require_once '../extend/alipay/pagepay/buildermodel/AlipayTradePagePayContentBuilder.php';

			//商户订单号，商户网站订单系统中唯一订单号，必填
			$out_trade_no = $orderInfo['order_no'];

			//订单名称，必填
			$subject = "支付";

			//付款金额，必填
			$total_amount =  $orderInfo['order_amount'];

			//商品描述，可空
			$body = '';

			//构造参数
			$payRequestBuilder = new \AlipayTradePagePayContentBuilder();
			$payRequestBuilder->setBody($body);
			$payRequestBuilder->setSubject($subject);
			$payRequestBuilder->setTotalAmount($total_amount);
			$payRequestBuilder->setOutTradeNo($out_trade_no);

			$aop = new \AlipayTradeService($config);

			
			$response = $aop->pagePay($payRequestBuilder,$config['return_url'],$config['notify_url']);

			//输出表单
			var_dump($response);

	}

	public function test(){ 
		$config= Config::get('alipay.');
		
		require_once '../extend/alipay/pagepay/service/AlipayTradeService.php';
		require_once '../extend/alipay/pagepay/buildermodel/AlipayTradePagePayContentBuilder.php';

		//商户订单号，商户网站订单系统中唯一订单号，必填
		$out_trade_no = 123456789;

		//订单名称，必填
		$subject = 12121212;

		//付款金额，必填
		$total_amount = 12;

		//商品描述，可空
		$body = '';

		//构造参数
		$payRequestBuilder = new \AlipayTradePagePayContentBuilder();
		$payRequestBuilder->setBody($body);
		$payRequestBuilder->setSubject($subject);
		$payRequestBuilder->setTotalAmount($total_amount);
		$payRequestBuilder->setOutTradeNo($out_trade_no);

		$aop = new \AlipayTradeService($config);

		
		$response = $aop->pagePay($payRequestBuilder,$config['return_url'],$config['notify_url']);

		//输出表单
		var_dump($response);
		}
	
	//同步跳转
	public function returnUrl(){

		$info=input('get.');
		//验证(检测信息是否是支付宝发送过来的)
			$config= Config::get('alipay.');
			require_once '../extend/alipay/pagepay/service/AlipayTradeService.php';
			$aop = new \AlipayTradeService($config);

			$result=$aop->check($info);
					//dump($result);die;
					//print_r($info);die;
				if(empty($result)){
					$this->erro('验签失败',url('index/index'));
				}

		
		//验证订单号
		if(empty($info['out_trade_no'])){
					$this->error('非法操作',url('index/index'));
			}
			$where=[
				['order_no','=',$info['out_trade_no']]
			];
			$order_model=model('Order');
			$orderInfo=$order_model->where($where)->find();
			if(empty($orderInfo)){
				echo "no";exit;
				$this->error('非法操作',url('index/index'));
			}
		//验证订单总金额
		if($orderInfo['order_amount']!=$info['total_amount']){
			$this->error('非法操作',url('index/index'));
		}
		$this->getCateData();
		return	$this->fetch();
	}
} 