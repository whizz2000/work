<?php
namespace app\index\controller;
use think\Controller;
use think\facade\Config;
class UserOrder extends Common
{
    /**定单列表 */
    public function orderList(){
        //查询所有该用户的订单信息
        $order_model=model('Order');
        $user_id=$this->getUserId();
        $orderListInfo=$order_model->where('user_id','=',$user_id)->select();
        $this->assign('orderListInfo', $orderListInfo);
        return $this->fetch();
    }
} 