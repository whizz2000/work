<?php

namespace app\index\model;

use think\Model;

class Cart extends Model
{
    protected $pk="cart_id";
}
 