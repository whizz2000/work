<?php

namespace app\index\model;

use think\Model;

class History extends Model
{
    protected $pk="id";
}
