<?php

namespace app\index\model;

use think\Model;

class OrderAddress extends Model
{
    protected $pk="id";
}
