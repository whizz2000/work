<?php

namespace app\index\model;

use think\Model;

class OrderDetail extends Model
{
    protected $pk="id";
}
