<?php
	return[
		// 默认控制器名
    'default_controller'     => 'Login',
    // 默认操作名
    'default_action'         => 'login',
	];
?>