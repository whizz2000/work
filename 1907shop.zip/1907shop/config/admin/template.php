<?php
	//模板设置
 return [
	'layout_on'=>true,
	'layout_name'=>'layout',
 ];
?>