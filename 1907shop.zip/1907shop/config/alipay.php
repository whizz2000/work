<?php
	return $config = array (	
		//应用ID,您的APPID。
		'app_id' => "2016101500692870",

		//商户私钥
		'merchant_private_key' => "MIIEowIBAAKCAQEAtBoRHwwhE3ml03+Z9yb67IZ2gxJwpKy27Eq0cdO7qB/2xcMeF6nLG/WnbLRzf+pf0G0QugXeHJWC58elOtVd1g2qEqFs4bemrSGoY5mf0jeMxluCwtBqZiTFODewQIaLbMvVNFmKJ1IY+P8HzxQ6XjWQo/6N0dp4TVokAtTo3z2AK0Gs6R3alYgG4gF5CfF8veFhSINo202UQxfQFQkaHOcIn0twV59aZzpMmMWXSkmASq6aGg9hs4F0khwEC/jbLTVPJQIAZXBEqNe9Wjon8g5r5ZmnSifU+YKXk41xjVyWwC7x1D/jV+mu8rLlQj7awHQXvPWyAXGEJOz/tzJiTQIDAQABAoIBAGMtv6PzT/ujj9gKesUJ6EB8Q6MmcnWczxcMhJXyXXLWN1TsgBPT4w/AlbRdIwWcEat7hCyMsqXXB8GPxcPCX+xSlgewcX9TXSwWTt6aaNKg2JsbJcUWdKFPOnQc5qiB7yG4le5AKL5CjZIBD1HP99yNbtuAgKTBxGIEc7RDfwH/takzD3anBSzqWH8Xe9RzZhTeAvAeVJG53pxVPMYj98NUGQuM8bdwpENaSO3k9lIoluulYFMPXqvqIu8zTFdQv/LR7wHnkSf8jdbChYmFi0BBA3Vv9PqOFoICAQOhLtZtukxnCozkbnhX1WluSuN3SBZsTiyxrp8iEqJ6l+TO1FkCgYEA1utgaqcLL1RiazFz6Ka9vjCrPfbJEXrVWuQAo7U5gKGRPKjFY5OhFANiwHnfbZnjUkRsBKoLaosnFtvHOjEM7kPo58ivnjTlQef+Jxj95hZghkDXlqq0oHu6jnP+GASuaQm0blHm4okUIYD+FeIZt14Vsxwmztce2O6zwjQAeDMCgYEA1ob28hc9W65x7+Rc98RQ4VJLEJeA6JBN43DaeXvTE3NHLoVXfn+C4XOHVVvKFfKEY9GnS7S1vdkkgdJ9gfsPn+FazfXcacS9auOTmf/0VtA6i+xgf+oQldq3FuMUlqOWsb996WnBS2V7L0N1pfr2w89nxCs6tii+RuhUYHyxO38CgYEAtrkBjUueJ8w/rNErsaZp9ZRdUt5JjrH3SUJGBOlkDSfQWllHEOUH8wL555j2S7GlYmFH0SNdd2T9g+KxXJktXDmif8XRAdoI/GKoY0dNPlzSDfJ9GNzjmvn233xgkL0SJ72XiJ/bg8h1tBJ+c856fLriChiqKfsdf+RaMoeRyp8CgYAlmD9ci6AQGhEThkSYkwnNgttuy+4mU2ui6RsQYRfLd89IosuDepsYIWPdHJncoMR8rbgQt1mGLLCOI7Ik/jdtwFNmdqiqzHSZb8plGYrbT+CCtujuYbmIWWzukNsBzydQfQt2xTa/nMgqrzrF3KY0CHvZz+2ZEKjPylVHF3MDxwKBgB6xe2eqobU/ni8IH+DS72TndSTxsnEj9wMbcZMwVBFfYD2iW0Y3SfrtIGQygGC4oUJNWn+Ftww1S65mEmFLR4qmVYk9AUwYa3b2Nl4QB6n1c6cuBjK3NXq4uh4LjJq01giPv/5Q150IIFSpY1XJ0bzYqg3/8PJTrIYjyrWnIreW",
		
		//异步通知地址
		'notify_url' => "http://外网可访问网关地址/alipay.trade.page.pay-PHP-UTF-8/notify_url.php",
		
		//同步跳转
		'return_url' => "http://www.1907shop.com/index.php/order/returnUrl",

		//编码格式
		'charset' => "UTF-8",

		//签名方式
		'sign_type'=>"RSA2",

		//支付宝网关
		'gatewayUrl' => "https://openapi.alipaydev.com/gateway.do",

		//支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
		'alipay_public_key' => "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtsIPOaO5G8KseXiDk4xAp2hzMWJgj7ejvbJli3HklIAbA6Nofl031OyZl6wHNWKOChUv63Yrg/mrwyfoLUnq3hUJ7q4AcT6QmOgQZhH346wMS072NWXu0JG8gBIXsphciKiDSQg5dK/UCGeYH6n2/3c/mgbzYxQ+lZSEuz7W49NFRroNfBywoFLP6UyOavSMUHcG+DtW5z8VsBdTCiXxIkY+vfBAi9NTYR9BGG3h3nL6Uv7BpQxn2Os23834bIKAvoplGcz7YiKrxce6LvH6j0WuIls2WDJM6upKbWLTujWTI++MOxdHNzG2X2Bczp7EHSoe47XwWXHdgTLTxmIXrQIDAQAB",
);
?>